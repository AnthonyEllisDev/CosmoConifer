CosmoConifer press kit
Solvane: The Iron Reach

  Steam:   https://store.steampowered.com/app/5226950/Solvane_The_Iron_Reach/
  App ID:  5226950
  Release: 2027

  logos/        studio mark and icon (SVG)
  artwork/      store capsules and title card
  screenshots/  in-game captures

Everything in this archive may be used in articles, videos and streams,
including monetised ones, without asking first. Please credit CosmoConifer
and link to https://cosmoconifer.com where it makes sense.

Descriptions and the full fact sheet: https://cosmoconifer.com/press/
Contact: hello@cosmoconifer.com
