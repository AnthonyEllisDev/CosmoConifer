CosmoConifer press kit
Solvane: The Iron Reach

  logos/        studio mark and icon (SVG)
  artwork/      store capsules and title card
  screenshots/  in-game captures

Everything in this archive may be used in articles, videos and streams,
including monetised ones, without asking first. Please credit CosmoConifer
and link to https://cosmoconifer.com where it makes sense.

Descriptions and the full fact sheet: https://cosmoconifer.com/press/
Contact: hello@cosmoconifer.com
